%function [x,r,ab,rp,data]=ratiol(a,b)
% calcula el ratio entre series temporales
% el ratio es respecto a b
% b puede  y a pudede tener varias columnas
% x= elementos comunes
% r= ratio
% ab= diferecia absoluta
% rp= ration porcentual

function [x,r,ab,rp,data]=ratiod(a,b)
% calcula el ratio entre respuestas o lamparas


[c,aa,bb]=intersect(a(:,1),b(:,1));
data=[c,a(aa,2:end),b(bb,2:end)];
%figure;
subplot(2,2,1);
ploty(data);grid;title('medidas');
datetick;
legend(inputname(1),inputname(2));
%r=[c,100*(a(aa,2)- b(bb,2))./b(bb,2)];
%r=[c,log(a(aa,2)./b(bb,2))];
if isempty(c) 
   error('no comon elemets to ratio')
end
if size(b,2)~=size(a,2) & size(b,2)==2
    b=[b(:,1),repmat(b(:,2),1,size(a,2)-1)];
end

subplot(2,2,2);
plot(data(:,2),data(:,3),'x');
rline;
grid;title('a vs b');


r=[c,(a(aa,2:end)./b(bb,2:end))];
ab=[c,(a(aa,2:end)-b(bb,2:end))];
rp=[c,100*(a(aa,2:end)-b(bb,2:end))./b(bb,2:end)];
subplot(2,3,4);
ploty(rp);grid;title('ratio %');
datetick;
subplot(2,3,5);
ploty(ab);grid;title('dif ab %');
datetick;
subplot(2,3,6);
ploty(r);grid;title('ratio');
datetick;

x=r;