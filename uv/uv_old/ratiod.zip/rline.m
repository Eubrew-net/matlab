function [h,ht] = lsline
% LSLINE Add least-squares fit line to scatter plot.
%   LSLINE superimposes the least squares line on each line object
%   in the current axis (Except LineStyles '-','--','.-'.)
% 
%   H = LSLINE returns the handle to the line object(s) in H.
%   
%   See also POLYFIT, POLYVAL.   

%   B.A. Jones 2-2-95
%   Copyright 1993-2002 The MathWorks, Inc. 
% $Revision: 2.9 $  $Date: 2002/01/17 21:31:06 $

lh = findobj(get(gca,'Children'),'Type','line');
if nargout == 1, 
   h = [];
end
count = 0;
for k = 1:length(lh)
    xdat = get(lh(k),'Xdata'); xdat = xdat(:);
    ydat = get(lh(k),'Ydata'); ydat = ydat(:);
    ok = ~(isnan(xdat) | isnan(ydat));
    datacolor = get(lh(k),'Color');
    style = get(lh(k),'LineStyle');
    if ~strcmp(style,'-') & ~strcmp(style,'--') & ~strcmp(style,'.-') & any(ok)
       count = count + 1;
       [beta,intb,r,rint,p] = linregress(ydat(ok,:),xdat(ok,:),0.05);
       newline = refline(beta);
       set(newline,'Color',datacolor);
       x=get(newline,'XData');y=get(newline,'YData');
       i(1,:)=intb(1,:)-beta(1);
       i(2,:)=intb(2,:)-beta(2);   
       
       %x=get(gca,'XTick');y=get(gca,'YTick');
       ht=text( x(1)+0.17*(x(end)-x(1)),y(1)+0.1*count*(y(end)-y(1)),...
           sprintf('  y=%.2E x+ %.2E r=%.3E +/-[%.2E,%.2E]',[beta;p(1);i(:,2)]))
       %r1=refline(intb(:,1));set(r1,'Color',datacolor);
       %r2=refline(intb(:,2));set(r2,'Color',datacolor);
       set(ht,'Color',datacolor);
       %set(ht,'BackgroundColor',[1,1,1]);
       
       if nargout >= 1
           h(count) = newline;    
       elseif nargout>1
           hb(count)=ht;
       end
       
   end
end
if count == 0
   disp('No allowed line types found. Nothing done.');
end
